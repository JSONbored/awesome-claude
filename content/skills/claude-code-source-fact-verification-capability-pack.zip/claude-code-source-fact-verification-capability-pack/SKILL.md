---
name: claude-code-source-fact-verification-capability-pack
description: "Expert Claude Code skill capability pack for source-grounded fact verification before agents edit code, documentation, prompts, or operational instructions."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-06-02**. Refresh official docs, changelogs, source repos, and package metadata whenever facts are version-sensitive or operationally risky.

## Retrieval Sources

- https://code.claude.com/docs/en/best-practices
- https://code.claude.com/docs/en/common-workflows
- https://code.claude.com/docs/en/skills

## Core Workflow

1. Extract claims that affect code, commands, compatibility, security, privacy, or user-facing documentation.
2. Rank sources by authority: local source of truth, official docs, maintained source repo, release notes, then secondary references.
3. Verify each claim against at least one primary source or mark it unsupported.
4. Cross-check repository evidence with `rg`, manifests, lockfiles, tests, generated files, and history when relevant.
5. Produce a concise evidence table before implementation.

## Capability Scope

- API and library behavior verification
- Documentation and README claim validation
- Security/privacy note grounding
- Migration guide and changelog reconciliation
- Issue-to-implementation evidence mapping

## Production Rules

- Treat dates, versions, pricing, APIs, security guidance, and package behavior as unstable unless verified.
- Separate exact source evidence from inference.
- Do not cite generated artifacts as source of truth when source files exist.
- Keep unsupported claims out of final content and code comments.

## Output Contract

1. Claim/evidence table with source URL or local file path.
2. Unsupported or conflicting claims list.
3. Implementation constraints derived from verified facts.
4. Explicit confidence and remaining caveats.
5. Recommended next validation command or manual check.
