---
name: claude-code-repo-migration-debugging-capability-pack
description: "Expert Claude Code skill capability pack for diagnosing repository migrations, dependency upgrades, build failures, and cross-file debugging with controlled validation."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-06-02**. Refresh runtime, framework, package-manager, and migration-guide docs before changing version-sensitive code.

## Retrieval Sources

- https://code.claude.com/docs/en/common-workflows
- https://code.claude.com/docs/en/troubleshooting
- https://code.claude.com/docs/en/skills

## Core Workflow

1. Establish a baseline: git status, runtime versions, failing command, shortest reproduction, and known-good reference if available.
2. Map affected files, packages, configs, generated outputs, and tests before editing.
3. Identify the smallest change that explains the failure and defer unrelated cleanup.
4. Apply fixes in rollback-safe increments with validation after each risky boundary.
5. End with a validation ladder from narrow reproduction to broader build/test checks.

## Capability Scope

- Dependency and runtime migrations
- Build, type-check, lint, and test failure diagnosis
- Monorepo package boundary debugging
- Partially applied refactor recovery
- Rollback-safe validation planning

## Production Rules

- Reproduce before changing unless reproduction is impossible; if impossible, state why.
- Prefer narrow, causal fixes over broad rewrites.
- Keep lockfile and generated artifact changes intentional.
- Validate the exact failing path before claiming the migration is complete.

## Output Contract

1. Reproduction summary and root-cause hypothesis.
2. Minimal patch plan with rollback points.
3. Applied changes grouped by cause.
4. Validation ladder with commands and results.
5. Remaining risks, skipped checks, and follow-up work.
