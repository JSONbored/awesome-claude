---
name: claude-code-mcp-production-readiness-capability-pack
description: "Expert Claude Code skill capability pack for taking MCP integrations from local proof-of-concept to production-ready, permissioned, observable workflows."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-06-02**. Re-check Claude Code MCP, settings, and current MCP specification docs before changing production server configuration.

## Retrieval Sources

- https://code.claude.com/docs/en/mcp
- https://code.claude.com/docs/en/settings
- https://modelcontextprotocol.io/specification/2025-06-18

## Core Workflow

1. Inventory every MCP server by name, scope, transport, command/URL, environment variables, and expected tools/resources.
2. Classify trust boundaries for local processes, project-shared configuration, remote endpoints, OAuth providers, and data stores.
3. Validate tool, prompt, and resource contracts with representative calls before approving broad access.
4. Reduce permissions to the minimum safe allowlist and record why each tool or server is approved.
5. Produce rollout, monitoring, incident response, and rollback instructions that a teammate can execute.

## Capability Scope

- Claude Code MCP server scope selection and conflict review
- Project `.mcp.json` readiness checks
- OAuth and secret-handling review
- MCP tool/resource/prompt contract validation
- Production rollout and rollback planning

## Production Rules

- Never approve an MCP server only because it starts successfully.
- Treat network-capable MCP servers as data-exfiltration paths until reviewed.
- Keep secrets in local environment or approved secret stores, not committed project files.
- Require a rollback path for every server, OAuth grant, and project-scoped config change.

## Output Contract

1. MCP readiness report with evidence and blocked items.
2. Exact config or command changes, with secrets redacted.
3. Permission and OAuth review table.
4. Validation commands or manual checks.
5. Rollback and incident-response plan.
